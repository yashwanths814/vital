// app/[locale]/authority/layout.tsx
"use client";

import { ReactNode, useEffect, useRef, useState } from "react";
import { useParams, usePathname, useRouter } from "next/navigation";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, db } from "../../lib/firebase";

type Role = "pdo" | "tdo" | "ddo" | "village_incharge";

export default function AuthorityLayout({ children }: { children: ReactNode }) {
    const router = useRouter();
    const pathname = usePathname();
    const params = useParams() as { locale?: string };
    const locale = params?.locale || "en";

    const [ready, setReady] = useState(false);
    const redirectingRef = useRef(false);

    const isLoginPage = pathname.includes("/authority/login");
    const isRegisterPage = pathname.includes("/authority/register");
    const isStatusPage = pathname.includes("/authority/status");

    useEffect(() => {
        const unsub = onAuthStateChanged(auth, async (u) => {
            if (redirectingRef.current) return;

            // 1) Not logged in
            if (!u) {
                if (!isLoginPage) {
                    redirectingRef.current = true;
                    router.replace(`/${locale}/authority/login`);
                    return;
                }
                setReady(true);
                return;
            }

            // 2) Logged in → fetch authority doc
            try {
                const snap = await getDoc(doc(db, "authorities", u.uid));

                // Not registered
                if (!snap.exists()) {
                    if (!isRegisterPage) {
                        redirectingRef.current = true;
                        router.replace(`/${locale}/authority/register`);
                        return;
                    }
                    setReady(true);
                    return;
                }

                const a = snap.data() as any;

                const verified =
                    a?.verified === true || a?.verification?.status === "verified";

                // Not verified → status page
                if (!verified) {
                    if (!isStatusPage) {
                        redirectingRef.current = true;
                        router.replace(`/${locale}/authority/status`);
                        return;
                    }
                    setReady(true);
                    return;
                }

                // Verified → go correct dashboard if currently on login/register/status
                const role = (a?.role || "pdo") as Role;

                const dash =
                    role === "pdo"
                        ? `/${locale}/authority/pdo/dashboard`
                        : role === "tdo"
                            ? `/${locale}/authority/tdo/dashboard`
                            : role === "ddo"
                                ? `/${locale}/authority/ddo/dashboard`
                                : `/${locale}/authority/vi/dashboard`;

                if (isLoginPage || isRegisterPage || isStatusPage) {
                    redirectingRef.current = true;
                    router.replace(dash);
                    return;
                }

                setReady(true);
            } catch (e) {
                // DO NOT bounce on temporary errors (permission/network)
                // Just allow page to render and show error UI instead of redirect loops.
                setReady(true);
            }
        });

        return () => unsub();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [locale, pathname]);

    if (!ready) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="font-bold text-green-700">Checking access…</div>
            </div>
        );
    }

    return <>{children}</>;
}
