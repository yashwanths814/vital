"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import { doc, getDoc, updateDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "../../../../..//lib/firebase";
import Screen from "../../../../../components/Screen";

export default function FundApprovePage() {
    const router = useRouter();
    const params = useParams() as { locale?: string; id?: string };
    const locale = params?.locale || "en";
    const id = params?.id as string;

    const t = useTranslations("fundApprove");

    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState("");
    const [data, setData] = useState<any>(null);

    const [comment, setComment] = useState("");
    const [acting, setActing] = useState<"approved" | "rejected" | "">("");

    useEffect(() => {
        const load = async () => {
            setErr("");
            setLoading(true);

            const user = auth.currentUser;
            if (!user) {
                router.replace(`/${locale}/authority/login`);
                return;
            }

            try {
                // 1) TDO profile check
                const aSnap = await getDoc(doc(db, "authorities", user.uid));
                if (!aSnap.exists()) {
                    router.replace(`/${locale}/authority/register`);
                    return;
                }

                const a = aSnap.data() as any;

                if (a?.role !== "tdo") {
                    router.replace(`/${locale}/role-select`);
                    return;
                }

                if (a?.verified !== true) {
                    router.replace(`/${locale}/authority/status`);
                    return;
                }

                const tdoDistrict = (a?.district || "").trim();
                const tdoTaluk = (a?.taluk || "").trim();

                // 2) Load fund request
                const frSnap = await getDoc(doc(db, "fund_requests", id));
                if (!frSnap.exists()) {
                    setErr(t("notFound"));
                    setLoading(false);
                    return;
                }

                const fr = { id: frSnap.id, ...(frSnap.data() as any) };

                /**
                 * 🔐 Scope lock:
                 * Your fund_requests should contain district & taluk fields.
                 * (When PDO creates request: include district/taluk in the request doc.)
                 */
                const reqDistrict = (fr?.district || "").trim();
                const reqTaluk = (fr?.taluk || "").trim();

                if (!reqDistrict || !reqTaluk) {
                    setErr(t("missingScope"));
                    setLoading(false);
                    return;
                }

                if (
                    tdoDistrict.toLowerCase() !== reqDistrict.toLowerCase() ||
                    tdoTaluk.toLowerCase() !== reqTaluk.toLowerCase()
                ) {
                    setErr(t("notAllowed"));
                    setLoading(false);
                    return;
                }

                setData(fr);
            } catch (e: any) {
                setErr(e?.message || t("loadFail"));
            } finally {
                setLoading(false);
            }
        };

        load();
    }, [id, locale, router, t]);

    const canAct = useMemo(() => {
        if (!data) return false;
        return data.status === "pending";
    }, [data]);

    const act = async (status: "approved" | "rejected") => {
        if (!data) return;
        if (!canAct) return;

        setErr("");
        setActing(status);

        try {
            await updateDoc(doc(db, "fund_requests", id), {
                status,
                tdoComment: (comment || "").trim(),
                decidedAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
            });

            router.back();
        } catch (e: any) {
            setErr(e?.message || t("actionFail"));
            setActing("");
        }
    };

    if (loading) {
        return (
            <Screen center>
                <div className="w-12 h-12 border-4 border-green-700 border-t-transparent rounded-full animate-spin" />
            </Screen>
        );
    }

    if (err) {
        return (
            <Screen padded>
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
                    {err}
                </div>

                <button
                    onClick={() => router.back()}
                    className="mt-4 w-full rounded-2xl bg-white border border-green-200 text-green-900 font-extrabold py-3"
                >
                    {t("back")}
                </button>
            </Screen>
        );
    }

    if (!data) return null;

    return (
        <Screen padded>
            {/* ✅ Mobile view: padding on small screens */}
            <div className="w-full max-w-xl mx-auto px-3 sm:px-0">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                    <div className="min-w-0 text-center sm:text-left">
                        <h1 className="text-xl sm:text-2xl font-extrabold text-green-900">
                            {t("title")}
                        </h1>
                        <p className="text-sm text-green-800/80 mt-1">
                            {t("subtitle")}
                        </p>
                    </div>

                    <button
                        onClick={() => router.back()}
                        className="w-full sm:w-auto shrink-0 px-3 py-2 rounded-xl border border-green-200 bg-white text-green-800 font-bold hover:bg-green-50"
                    >
                        {t("back")}
                    </button>
                </div>

                {/* Card */}
                <div className="mt-5 bg-white border border-green-100 rounded-2xl p-5 shadow-sm">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                        <div className="min-w-0 text-left">
                            <p className="text-xs text-green-900/60">{t("requestId")}</p>
                            <p className="font-extrabold text-green-900 break-all">{data.id}</p>
                        </div>

                        <span
                            className={`self-start sm:self-auto shrink-0 px-3 py-1 rounded-full text-xs font-extrabold border ${data.status === "pending"
                                ? "border-yellow-200 bg-yellow-50 text-yellow-800"
                                : data.status === "approved"
                                    ? "border-green-200 bg-green-50 text-green-800"
                                    : "border-red-200 bg-red-50 text-red-700"
                                }`}
                        >
                            {t(`status_${data.status}` as any)}
                        </span>
                    </div>

                    <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="rounded-xl border border-green-100 bg-green-50 px-4 py-3">
                            <p className="text-xs font-bold text-green-900/70">{t("amount")}</p>
                            <p className="text-lg font-extrabold text-green-900">
                                ₹{data.amount || 0}
                            </p>
                        </div>

                        <div className="rounded-xl border border-green-100 bg-green-50 px-4 py-3">
                            <p className="text-xs font-bold text-green-900/70">{t("scope")}</p>
                            <p className="text-sm font-bold text-green-900">
                                {data.district} • {data.taluk}
                            </p>
                        </div>
                    </div>

                    <div className="mt-4">
                        <p className="text-xs font-bold text-green-900/70">{t("reason")}</p>
                        <p className="text-sm text-green-900/80 mt-1">
                            {data.reason || "—"}
                        </p>
                    </div>

                    <div className="mt-4">
                        <label className="text-xs font-bold text-green-900/70">
                            {t("comment")}
                        </label>

                        <textarea
                            value={comment}
                            onChange={(e) => setComment(e.target.value)}
                            placeholder={t("commentPh")}
                            rows={3}
                            className="mt-1 w-full rounded-xl border border-green-200 p-3 text-green-900 font-semibold outline-none focus:ring-2 focus:ring-green-300"
                        />
                    </div>

                    {!canAct && (
                        <div className="mt-4 rounded-xl border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm font-semibold text-yellow-800">
                            {t("alreadyDecided")}
                        </div>
                    )}

                    {/* ✅ Mobile: buttons stack, desktop: 2 columns */}
                    <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <button
                            onClick={() => act("approved")}
                            disabled={!canAct || acting !== ""}
                            className="rounded-2xl bg-green-700 text-white font-extrabold py-3 hover:bg-green-800 disabled:opacity-60"
                        >
                            {acting === "approved" ? t("approving") : t("approve")}
                        </button>

                        <button
                            onClick={() => act("rejected")}
                            disabled={!canAct || acting !== ""}
                            className="rounded-2xl bg-red-600 text-white font-extrabold py-3 hover:bg-red-700 disabled:opacity-60"
                        >
                            {acting === "rejected" ? t("rejecting") : t("reject")}
                        </button>
                    </div>
                </div>
            </div>
        </Screen>
    );
}
