"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import {
    collection,
    doc,
    getDoc,
    getDocs,
    query,
    where,
} from "firebase/firestore";
import { auth, db } from "../../../../../lib/firebase";
import Screen from "../../../../../components/Screen";

// If you already use leaflet elsewhere, keep consistent
import dynamic from "next/dynamic";

// Load map only on client
const Map = dynamic(() => import("../../../../../components/Map"), { ssr: false });

type FundReq = {
    id: string;
    amount: number;
    reason: string;
    status: string;
    panchayatId: string;
    issueLat?: number;
    issueLng?: number;
};

export default function TDOFundMapPage() {
    const router = useRouter();
    const params = useParams() as { locale?: string };
    const locale = params?.locale || "en";
    const t = useTranslations("tdoFundMap");

    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState("");
    const [funds, setFunds] = useState<FundReq[]>([]);
    const [scope, setScope] = useState({ district: "", taluk: "" });

    useEffect(() => {
        const load = async () => {
            setLoading(true);
            setErr("");

            const user = auth.currentUser;
            if (!user) {
                router.replace(`/${locale}/authority/login`);
                return;
            }

            try {
                // 1️⃣ TDO profile
                const snap = await getDoc(doc(db, "authorities", user.uid));
                if (!snap.exists()) {
                    router.replace(`/${locale}/authority/register`);
                    return;
                }

                const a = snap.data() as any;
                if (a.role !== "tdo") {
                    router.replace(`/${locale}/role-select`);
                    return;
                }
                if (a.verified !== true) {
                    router.replace(`/${locale}/authority/status`);
                    return;
                }

                if (!a.district || !a.taluk) {
                    setErr(t("missingScope"));
                    setLoading(false);
                    return;
                }

                setScope({ district: a.district, taluk: a.taluk });

                // 2️⃣ Fund requests for taluk
                const qy = query(
                    collection(db, "fund_requests"),
                    where("district", "==", a.district),
                    where("taluk", "==", a.taluk),
                    where("status", "==", "pending")
                );

                const snap2 = await getDocs(qy);
                setFunds(
                    snap2.docs.map((d) => ({
                        id: d.id,
                        ...(d.data() as any),
                    }))
                );
            } catch (e: any) {
                setErr(e?.message || t("loadFail"));
            } finally {
                setLoading(false);
            }
        };

        load();
    }, [router, locale, t]);

    return (
        <Screen padded={false}>
            {/* Header */}
            <div className="px-4 py-4 border-b border-green-200 bg-white">
                <div className="flex items-start justify-between gap-3">
                    <div>
                        <h1 className="text-lg sm:text-xl font-extrabold text-green-900">
                            {t("title")}
                        </h1>
                        <p className="text-xs text-green-800/80">
                            {scope.taluk}, {scope.district}
                        </p>
                    </div>

                    <button
                        onClick={() => router.back()}
                        className="px-3 py-2 rounded-xl border border-green-200 bg-white text-green-900 font-bold"
                    >
                        {t("back")}
                    </button>
                </div>
            </div>

            {/* Body */}
            {loading && (
                <div className="py-20 text-center text-green-700 font-semibold">
                    {t("loading")}
                </div>
            )}

            {!loading && err && (
                <div className="m-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
                    {err}
                </div>
            )}

            {!loading && !err && funds.length === 0 && (
                <div className="m-4 rounded-2xl border border-green-200 bg-white px-4 py-4 text-sm font-semibold text-green-800">
                    {t("empty")}
                </div>
            )}

            {!loading && !err && funds.length > 0 && (
                <div className="h-[calc(100dvh-120px)]">
                    <Map
                        markers={funds
                            .filter((f) => f.issueLat && f.issueLng)
                            .map((f) => ({
                                id: f.id,
                                lat: f.issueLat!,
                                lng: f.issueLng!,
                                title: `₹${f.amount} • ${f.panchayatId}`,
                                subtitle: f.reason,
                                onClick: () =>
                                    router.push(
                                        `/${locale}/authority/tdo/fund-approve/${f.id}`
                                    ),
                            }))}
                    />
                </div>
            )}
        </Screen>
    );
}
