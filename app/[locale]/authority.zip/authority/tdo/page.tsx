// app/[locale]/authority/tdo/page.tsx
"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Screen from "../../../components/Screen";
import { auth, db } from "../../../lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import {
    collection,
    doc,
    getDoc,
    getDocs,
    query,
    where,
    orderBy,
    Timestamp,
} from "firebase/firestore";

type Locale = "en" | "kn" | "hi";

type Stat = {
    label: string;
    value: number;
    to: string;
};

export default function TDODashboard() {
    const router = useRouter();
    const params = useParams() as { locale?: string };
    const locale = (params?.locale || "en") as Locale;

    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState("");
    const [stats, setStats] = useState<Stat[]>([]);

    /* =======================
       🌐 TRANSLATIONS
       ======================= */
    const t = useMemo(() => {
        const L: Record<Locale, any> = {
            en: {
                title: "TDO Dashboard",
                subtitle: "Taluk-level issue monitoring & escalation",
                loading: "Loading…",
                errPerm: "Missing or insufficient permissions.",
                cards: {
                    total: "Total Issues",
                    pending: "Pending Issues",
                    escalated: "Escalated Issues",
                    breached: "SLA Breached",
                },
            },
            kn: {
                title: "ತಾಲೂಕು ಅಭಿವೃದ್ಧಿ ಅಧಿಕಾರಿ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
                subtitle: "ತಾಲೂಕು ಮಟ್ಟದ ಸಮಸ್ಯೆಗಳ ಮೇಲ್ವಿಚಾರಣೆ ಮತ್ತು ಏರಿಕೆ",
                loading: "ಲೋಡ್ ಆಗುತ್ತಿದೆ…",
                errPerm: "ಅನುಮತಿ ಇಲ್ಲ ಅಥವಾ ಸಾಕಷ್ಟು ಅನುಮತಿ ಇಲ್ಲ.",
                cards: {
                    total: "ಒಟ್ಟು ಸಮಸ್ಯೆಗಳು",
                    pending: "ಬಾಕಿ ಸಮಸ್ಯೆಗಳು",
                    escalated: "ಏರಿಸಲಾದ ಸಮಸ್ಯೆಗಳು",
                    breached: "SLA ಉಲ್ಲಂಘನೆ",
                },
            },
            hi: {
                title: "TDO डैशबोर्ड",
                subtitle: "तालुका स्तर पर समस्या निगरानी और एस्केलेशन",
                loading: "लोड हो रहा है…",
                errPerm: "अनुमति नहीं है या पर्याप्त अनुमति नहीं है।",
                cards: {
                    total: "कुल समस्याएँ",
                    pending: "लंबित समस्याएँ",
                    escalated: "एस्केलेटेड समस्याएँ",
                    breached: "SLA उल्लंघन",
                },
            },
        };
        return L[locale] || L.en;
    }, [locale]);

    /* =======================
       ⏱ SLA CONFIG
       ======================= */
    const SLA = {
        submitted: 2,
        vi_verified: 3,
        pdo_assigned: 5,
        in_progress: 7,
    } as const;

    const daysBetween = (a: Timestamp, b: Timestamp) =>
        Math.floor((b.toMillis() - a.toMillis()) / 86400000);

    /* =======================
       🔐 AUTH + DATA
       ======================= */
    useEffect(() => {
        const unsub = onAuthStateChanged(auth, async (user) => {
            try {
                setLoading(true);
                setErr("");

                if (!user) {
                    router.replace(`/${locale}/authority/login`);
                    return;
                }

                const aSnap = await getDoc(doc(db, "authorities", user.uid));
                if (!aSnap.exists()) {
                    router.replace(`/${locale}/authority/login`);
                    return;
                }

                const a = aSnap.data() as any;
                const isVerified =
                    a?.verified === true || a?.verification?.status === "verified";

                if (a.role !== "tdo" || !isVerified) {
                    router.replace(`/${locale}/authority/status`);
                    return;
                }

                const { district, taluk } = a;
                if (!district || !taluk) {
                    setErr("District / Taluk missing in authority profile.");
                    setLoading(false);
                    return;
                }

                const q = query(
                    collection(db, "issues"),
                    where("district", "==", district),
                    where("taluk", "==", taluk),
                    orderBy("createdAt", "desc")
                );

                const snap = await getDocs(q);
                const now = Timestamp.now();

                let total = 0,
                    pending = 0,
                    escalated = 0,
                    breached = 0;

                snap.docs.forEach((d) => {
                    const it = d.data() as any;
                    total++;

                    if (it.status !== "resolved" && it.status !== "closed") pending++;

                    if (["escalated_tdo", "escalated_ddo"].includes(it.status))
                        escalated++;

                    if (it.createdAt && SLA[it.status as keyof typeof SLA]) {
                        const days = daysBetween(it.createdAt, now);
                        if (days > SLA[it.status as keyof typeof SLA]) breached++;
                    }
                });

                setStats([
                    {
                        label: t.cards.total,
                        value: total,
                        to: `/${locale}/authority/tdo/issues`,
                    },
                    {
                        label: t.cards.pending,
                        value: pending,
                        to: `/${locale}/authority/tdo/issues?status=pending`,
                    },
                    {
                        label: t.cards.escalated,
                        value: escalated,
                        to: `/${locale}/authority/tdo/issues?status=escalated`,
                    },
                    {
                        label: t.cards.breached,
                        value: breached,
                        to: `/${locale}/authority/tdo/analytics`,
                    },
                ]);

                setLoading(false);
            } catch (e: any) {
                console.error("TDO DASHBOARD ERROR:", e);
                setErr(e?.message || t.errPerm);
                setLoading(false);
            }
        });

        return () => unsub();
    }, [router, locale, t.errPerm]);

    /* =======================
       🖥️ UI
       ======================= */
    return (
        <Screen padded>
            <div className="max-w-6xl mx-auto">
                <h1 className="text-xl sm:text-2xl font-extrabold text-green-900">
                    {t.title}
                </h1>
                <p className="text-xs sm:text-sm text-green-800/70 mt-1">
                    {t.subtitle}
                </p>

                {loading && (
                    <div className="mt-6 text-sm text-green-900/80">{t.loading}</div>
                )}

                {err && (
                    <div className="mt-6 rounded-xl bg-red-50 border border-red-200 p-3 text-red-700 text-sm">
                        {err}
                    </div>
                )}

                {!loading && !err && (
                    <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        {stats.map((s) => (
                            <button
                                key={s.label}
                                onClick={() => router.push(s.to)}
                                className="text-left bg-white border border-green-100 rounded-2xl p-5 shadow-sm hover:shadow active:scale-[0.99] transition"
                            >
                                <div className="text-xs sm:text-sm text-green-800/70">
                                    {s.label}
                                </div>
                                <div className="mt-2 text-3xl sm:text-4xl font-extrabold text-green-900">
                                    {s.value}
                                </div>
                            </button>
                        ))}
                    </div>
                )}
            </div>
        </Screen>
    );
}
