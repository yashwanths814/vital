// app/[locale]/authority/tdo/dashboard/page.tsx
"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { useTranslations } from "next-intl";
import Screen from "../../../../components/Screen";
import { auth, db } from "../../../../lib/firebase";
import {
    collection,
    doc,
    getCountFromServer,
    getDoc,
    getDocs,
    orderBy,
    query,
    serverTimestamp,
    updateDoc,
    where,
    Timestamp,
} from "firebase/firestore";
import {
    FiClock,
    FiCheckCircle,
    FiAlertCircle,
    FiRefreshCw,
    FiDollarSign,
    FiTrendingUp,
    FiUser,
    FiLogOut,
    FiBarChart2,
    FiInbox,
    FiActivity,
    FiUsers,
    FiChevronRight,
    FiMessageSquare,
    FiCheck,
    FiX,
    FiHome,
    FiFileText,
} from "react-icons/fi";

type FundReq = {
    id: string;
    status: "pending" | "approved" | "rejected";
    amount?: number;
    reason?: string;
    issueId?: string;

    district?: string;
    taluk?: string;
    districtId?: string;
    talukId?: string;

    createdAt?: any;
    panchayatId?: string;
    pdoName?: string;
    issueTitle?: string;
    tdoComment?: string;
};

function fmtDate(v: any) {
    try {
        if (!v) return "";
        if (v instanceof Timestamp) return v.toDate().toLocaleString();
        if (v?.toDate) return v.toDate().toLocaleString();
        if (typeof v === "string") return new Date(v).toLocaleString();
        return "";
    } catch {
        return "";
    }
}

// Prefer IDs if available, fallback to names
function buildScopeFromAuthority(a: any) {
    const districtId = String(a?.districtId || "").trim();
    const talukId = String(a?.talukId || "").trim();

    const district = String(a?.district || "").trim();
    const taluk = String(a?.taluk || "").trim();

    const useIds = Boolean(districtId && talukId);

    return { useIds, districtId, talukId, district, taluk };
}

export default function TDODashboardOnePage() {
    const router = useRouter();
    const params = useParams() as { locale?: string };
    const locale = params?.locale || "en";
    const t = useTranslations("tdoOnePage");

    // NOTE: authority/layout.tsx should already ensure user is authenticated + verified + role=tdo.
    // This page must NOT redirect to login/status/register to avoid flicker loops.

    const [booting, setBooting] = useState(true);

    const [authority, setAuthority] = useState<any>(null);
    const [scope, setScope] = useState({
        useIds: false,
        districtId: "",
        talukId: "",
        district: "",
        taluk: "",
    });

    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [err, setErr] = useState("");

    const [tab, setTab] = useState<"pending" | "approved" | "rejected">("pending");
    const [items, setItems] = useState<FundReq[]>([]);
    const [counts, setCounts] = useState({ pending: 0, approved: 0, rejected: 0 });
    const [animatedCounts, setAnimatedCounts] = useState({
        pending: 0,
        approved: 0,
        rejected: 0,
    });

    const [open, setOpen] = useState(false);
    const [active, setActive] = useState<FundReq | null>(null);
    const [comment, setComment] = useState("");
    const [acting, setActing] = useState(false);

    const tabs = useMemo(
        () => [
            {
                key: "pending" as const,
                label: t("pending"),
                icon: <FiClock className="w-4 h-4" />,
                color: "text-amber-900",
                bgColor: "bg-amber-100",
                borderColor: "border-amber-200",
            },
            {
                key: "approved" as const,
                label: t("approved"),
                icon: <FiCheckCircle className="w-4 h-4" />,
                color: "text-green-900",
                bgColor: "bg-green-100",
                borderColor: "border-green-200",
            },
            {
                key: "rejected" as const,
                label: t("rejected"),
                icon: <FiAlertCircle className="w-4 h-4" />,
                color: "text-red-900",
                bgColor: "bg-red-100",
                borderColor: "border-red-200",
            },
        ],
        [t]
    );

    const scopeWhere = () => {
        if (scope.useIds) {
            return [
                where("districtId", "==", scope.districtId),
                where("talukId", "==", scope.talukId),
            ] as const;
        }
        return [where("district", "==", scope.district), where("taluk", "==", scope.taluk)] as const;
    };

    const loadCounts = async () => {
        const base = collection(db, "fund_requests");

        const makeCount = async (status: "pending" | "approved" | "rejected") => {
            const qy = query(base, ...scopeWhere(), where("status", "==", status));
            const snap = await getCountFromServer(qy);
            return snap.data().count;
        };

        const [p, a, r] = await Promise.all([makeCount("pending"), makeCount("approved"), makeCount("rejected")]);

        const newCounts = { pending: p, approved: a, rejected: r };
        setCounts(newCounts);

        setAnimatedCounts({ pending: 0, approved: 0, rejected: 0 });
        setTimeout(() => setAnimatedCounts(newCounts), 250);
    };

    const loadList = async (status: "pending" | "approved" | "rejected") => {
        const qy = query(
            collection(db, "fund_requests"),
            ...scopeWhere(),
            where("status", "==", status),
            orderBy("createdAt", "desc")
        );
        const snap = await getDocs(qy);
        setItems(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
    };

    const loadDashboardData = async (statusOverride?: "pending" | "approved" | "rejected") => {
        setErr("");
        setLoading(true);
        try {
            await loadCounts();
            await loadList(statusOverride || tab);
        } catch (e: any) {
            setErr(e?.message || t("loadFail"));
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    // ✅ boot once: get authority doc (NO redirects)
    useEffect(() => {
        let alive = true;

        (async () => {
            try {
                setErr("");
                setBooting(true);

                const u = auth.currentUser;
                if (!u) {
                    // Layout should prevent this, but just in case:
                    if (!alive) return;
                    setErr("Not signed in. Please go back and login again.");
                    return;
                }

                const aSnap = await getDoc(doc(db, "authorities", u.uid));
                if (!aSnap.exists()) {
                    if (!alive) return;
                    setErr("Authority profile not found.");
                    return;
                }

                const a = aSnap.data() as any;

                // Do NOT redirect here. Just show error if mismatch (layout should already block)
                const verified = a?.verified === true || a?.verification?.status === "verified";
                if (!verified) {
                    if (!alive) return;
                    setErr("Not verified yet. Please wait for admin verification.");
                    setAuthority(a);
                    return;
                }

                if (a?.role !== "tdo") {
                    if (!alive) return;
                    setErr("You are not authorized for TDO dashboard.");
                    setAuthority(a);
                    return;
                }

                const sc = buildScopeFromAuthority(a);
                if (!alive) return;

                setAuthority(a);
                setScope(sc);

                if (
                    (sc.useIds && (!sc.districtId || !sc.talukId)) ||
                    (!sc.useIds && (!sc.district || !sc.taluk))
                ) {
                    setErr(t("missingScope"));
                    return;
                }

                await loadDashboardData("pending"); // first load tab data
            } catch (e: any) {
                if (!alive) return;
                setErr(e?.message || t("loadFail"));
            } finally {
                if (!alive) return;
                setBooting(false);
            }
        })();

        return () => {
            alive = false;
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [locale]);

    // reload list when tab changes (only if scope is present)
    useEffect(() => {
        if (booting) return;
        if (
            (scope.useIds && (!scope.districtId || !scope.talukId)) ||
            (!scope.useIds && (!scope.district || !scope.taluk))
        ) {
            return;
        }
        loadList(tab).catch(() => { });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [tab]);

    const handleRefresh = async () => {
        setRefreshing(true);
        await loadDashboardData();
        setTimeout(() => setRefreshing(false), 350);
    };

    const handleLogout = async () => {
        try {
            await auth.signOut();
            router.replace(`/${locale}/role-select`);
        } catch (e) {
            console.error(e);
        }
    };

    const openModal = (x: FundReq) => {
        setActive(x);
        setComment("");
        setOpen(true);
    };

    const closeModal = () => {
        setOpen(false);
        setActive(null);
        setComment("");
    };

    const act = async (status: "approved" | "rejected") => {
        if (!active) return;
        setActing(true);
        setErr("");

        try {
            await updateDoc(doc(db, "fund_requests", active.id), {
                status,
                tdoComment: comment || "",
                decidedAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
            });

            await loadDashboardData();
            closeModal();
        } catch (e: any) {
            setErr(e?.message || t("actionFail"));
        } finally {
            setActing(false);
        }
    };

    // Boot screen
    if (booting) {
        return (
            <Screen padded>
                <div className="min-h-screen flex items-center justify-center">
                    <div className="text-blue-700 font-bold">Loading dashboard…</div>
                </div>
            </Screen>
        );
    }

    const scopeLabel = scope.useIds
        ? `${scope.districtId} • ${scope.talukId}`
        : `${scope.district} • ${scope.taluk}`;

    return (
        <Screen padded>
            <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fadeIn { animation: fadeIn 0.6s ease-out forwards; }
        .refresh-spin { animation: spin 0.8s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .stat-card { transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 12px 24px rgba(59, 130, 246, 0.15); }
      `}</style>

            <div className="min-h-screen bg-gradient-to-b from-blue-50 via-white to-white p-4 pb-20">
                {/* Header */}
                <div className="mb-8 animate-fadeIn">
                    <div className="flex items-center justify-between mb-4">
                        <div>
                            <h1 className="text-3xl font-bold text-blue-900 tracking-tight">
                                {t("title")}
                            </h1>
                            <p className="text-blue-700/80 mt-2 text-sm font-semibold flex items-center gap-2">
                                <FiActivity className="w-4 h-4" />
                                {t("welcome")}{" "}
                                {auth.currentUser?.displayName ||
                                    auth.currentUser?.email?.split("@")[0] ||
                                    "TDO"}
                            </p>
                            <div className="mt-1 text-xs bg-blue-100 text-blue-800 px-3 py-1 rounded-full inline-flex items-center gap-1">
                                <FiUsers className="w-3 h-3" />
                                <span>
                                    Scope: <strong>{scopeLabel}</strong>
                                </span>
                            </div>
                        </div>

                        <button
                            onClick={handleRefresh}
                            disabled={refreshing}
                            className="p-3 rounded-xl border-2 border-blue-100 bg-white hover:bg-blue-50 active:scale-95 transition-all duration-200"
                            title="Refresh"
                        >
                            <FiRefreshCw className={`w-5 h-5 text-blue-700 ${refreshing ? "refresh-spin" : ""}`} />
                        </button>
                    </div>

                    <div className="flex items-center gap-2 text-sm text-blue-600/80 bg-blue-50/50 rounded-xl p-3">
                        <FiBarChart2 className="w-4 h-4" />
                        <span className="font-semibold">{t("stats") || "Funding Statistics"}</span>
                        <span className="ml-auto text-blue-900 font-bold">
                            {counts.pending + counts.approved + counts.rejected} Total Requests
                        </span>
                    </div>
                </div>

                {/* Error */}
                {err && (
                    <div className="mb-6 p-4 bg-red-50 border-2 border-red-100 rounded-2xl animate-fadeIn">
                        <p className="text-red-700 text-sm">{err}</p>
                    </div>
                )}

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                    {tabs.map((tabItem, index) => (
                        <div
                            key={tabItem.key}
                            className={`stat-card ${tabItem.borderColor} border-2 rounded-2xl p-4 shadow-lg animate-fadeIn`}
                            style={{ animationDelay: `${index * 100}ms` }}
                        >
                            <div className="flex items-center justify-between mb-3">
                                <div className={`p-2 ${tabItem.bgColor} rounded-lg`}>
                                    {tabItem.icon}
                                </div>
                                {counts[tabItem.key] > 0 && (
                                    <span className={`text-xs font-bold px-2 py-1 rounded-full ${tabItem.bgColor} ${tabItem.color}`}>
                                        {animatedCounts[tabItem.key] || 0}
                                    </span>
                                )}
                            </div>
                            <div className={`text-2xl font-bold ${tabItem.color} mb-1`}>
                                {animatedCounts[tabItem.key] || 0}
                            </div>
                            <div className="text-xs font-semibold text-gray-600">{tabItem.label}</div>
                            <div className={`h-1 w-full bg-gradient-to-r ${tabItem.bgColor.replace("bg-", "from-")} to-transparent rounded-full mt-3`} />
                        </div>
                    ))}
                </div>

                {/* Tabs */}
                <div className="flex gap-2 overflow-x-auto mb-6">
                    {tabs.map((x) => {
                        const activeTab = tab === x.key;
                        return (
                            <button
                                key={x.key}
                                onClick={() => setTab(x.key)}
                                className={[
                                    "flex items-center gap-2 px-4 py-3 rounded-2xl border font-bold whitespace-nowrap transition-all duration-300",
                                    activeTab
                                        ? "bg-blue-700 text-white border-blue-700 shadow-lg"
                                        : "bg-white text-blue-900 border-blue-200 hover:bg-blue-50 hover:border-blue-300",
                                ].join(" ")}
                            >
                                {x.icon}
                                {x.label}
                                {counts[x.key] > 0 && (
                                    <span className={`ml-2 px-2 py-1 rounded-full text-xs ${activeTab ? "bg-white/20 text-white" : `${x.bgColor} ${x.color}`}`}>
                                        {counts[x.key]}
                                    </span>
                                )}
                            </button>
                        );
                    })}
                </div>

                {/* List */}
                <div className="space-y-4">
                    {loading ? (
                        <div className="text-center text-blue-700 font-semibold py-10">
                            {t("loading")}
                        </div>
                    ) : items.length === 0 ? (
                        <div className="rounded-2xl border-2 border-blue-100 bg-white/50 p-8 text-center">
                            <FiInbox className="w-12 h-12 text-blue-300 mx-auto mb-4" />
                            <p className="text-blue-700 font-semibold">{t("empty")}</p>
                            <p className="text-blue-500/70 text-sm mt-2">No fund requests in this category</p>
                        </div>
                    ) : (
                        items.map((x, index) => (
                            <div
                                key={x.id}
                                className="bg-white border-2 border-blue-100 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all duration-300 animate-fadeIn"
                                style={{ animationDelay: `${index * 50}ms` }}
                            >
                                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-3 mb-3">
                                            <div className={`p-2 rounded-xl ${x.status === "pending"
                                                    ? "bg-amber-100 text-amber-700"
                                                    : x.status === "approved"
                                                        ? "bg-green-100 text-green-700"
                                                        : "bg-red-100 text-red-700"
                                                }`}>
                                                <FiDollarSign className="w-5 h-5" />
                                            </div>
                                            <div>
                                                <div className="text-2xl font-bold text-blue-900">
                                                    ₹{x.amount?.toLocaleString() || 0}
                                                </div>
                                                <div className="text-sm text-blue-700/70">
                                                    {x.panchayatId ? `Panchayat: ${x.panchayatId}` : "Panchayat ID not specified"}
                                                </div>
                                            </div>
                                        </div>

                                        <div className="space-y-2">
                                            {x.reason && (
                                                <div className="text-sm text-gray-700">
                                                    <span className="font-semibold text-blue-900">Reason:</span> {x.reason}
                                                </div>
                                            )}
                                            {x.issueTitle && (
                                                <div className="text-sm text-gray-700">
                                                    <span className="font-semibold text-blue-900">Issue:</span> {x.issueTitle}
                                                </div>
                                            )}
                                            <div className="text-xs text-gray-500">Created: {fmtDate(x.createdAt)}</div>
                                        </div>
                                    </div>

                                    <div className="flex flex-col gap-2">
                                        {x.status === "pending" && (
                                            <button
                                                onClick={() => openModal(x)}
                                                className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold hover:from-blue-700 hover:to-blue-800 active:scale-95 transition-all duration-200"
                                            >
                                                Review Request
                                            </button>
                                        )}
                                        <div className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${x.status === "pending"
                                                ? "bg-amber-100 text-amber-800"
                                                : x.status === "approved"
                                                    ? "bg-green-100 text-green-800"
                                                    : "bg-red-100 text-red-800"
                                            }`}>
                                            {x.status === "pending" ? <FiClock className="w-3 h-3" /> : x.status === "approved" ? <FiCheck className="w-3 h-3" /> : <FiX className="w-3 h-3" />}
                                            {t(`status_${x.status}` as any)}
                                        </div>
                                    </div>
                                </div>

                                {x.status !== "pending" && (
                                    <div className="mt-4 p-3 bg-gray-50 rounded-xl border border-gray-200">
                                        <div className="flex items-center gap-2 text-sm text-gray-700">
                                            <FiMessageSquare className="w-4 h-4" />
                                            <span className="font-semibold">TDO Comment:</span>
                                            <span>{x.tdoComment || "No comment provided"}</span>
                                        </div>
                                    </div>
                                )}

                                <button
                                    onClick={() => openModal(x)}
                                    className="mt-4 text-sm font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1 hover:gap-2 transition-all"
                                >
                                    View Details <FiChevronRight className="w-4 h-4" />
                                </button>
                            </div>
                        ))
                    )}
                </div>

                {/* Bottom Navigation */}
                <div className="fixed bottom-4 left-4 right-4 bg-white/90 backdrop-blur-lg border-2 border-blue-100 rounded-2xl p-2 shadow-xl animate-fadeIn">
                    <div className="grid grid-cols-4 gap-1">
                        <button
                            className="flex flex-col items-center justify-center p-3 rounded-xl transition-all bg-gradient-to-b from-blue-100 to-blue-50"
                            onClick={() => router.push(`/${locale}/authority/tdo/dashboard`)}
                        >
                            <FiHome className="w-5 h-5 text-blue-700" />
                            <span className="text-xs mt-1 font-medium text-blue-800 font-bold">Dashboard</span>
                        </button>

                        <button
                            className="flex flex-col items-center justify-center p-3 rounded-xl transition-all hover:bg-blue-50"
                            onClick={() => router.push(`/${locale}/authority/tdo/requests`)}
                        >
                            <FiFileText className="w-5 h-5 text-blue-600/70" />
                            <span className="text-xs mt-1 font-medium text-blue-700/70">Requests</span>
                        </button>

                        <button
                            className="flex flex-col items-center justify-center p-3 rounded-xl transition-all hover:bg-blue-50"
                            onClick={() => router.push(`/${locale}/authority/tdo/analytics`)}
                        >
                            <FiTrendingUp className="w-5 h-5 text-blue-600/70" />
                            <span className="text-xs mt-1 font-medium text-blue-700/70">Analytics</span>
                        </button>

                        <button
                            className="flex flex-col items-center justify-center p-3 rounded-xl transition-all hover:bg-blue-50"
                            onClick={() => router.push(`/${locale}/authority/tdo/profile`)}
                        >
                            <FiUser className="w-5 h-5 text-blue-600/70" />
                            <span className="text-xs mt-1 font-medium text-blue-700/70">Profile</span>
                        </button>
                    </div>
                </div>

                {/* Logout Button */}
                <button
                    onClick={handleLogout}
                    className="fixed top-4 right-4 p-3 rounded-xl border-2 border-red-100 bg-white hover:bg-red-50 text-red-700 hover:text-red-900 transition-all duration-200 hover:scale-105 shadow-sm"
                    title="Logout"
                >
                    <FiLogOut className="w-5 h-5" />
                </button>
            </div>

            {/* Modal */}
            {open && active && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={closeModal} />
                    <div className="relative w-full max-w-lg bg-white rounded-3xl border-2 border-blue-100 shadow-2xl p-6 animate-fadeIn">
                        <div className="flex items-start justify-between gap-3 mb-6">
                            <div>
                                <h2 className="text-2xl font-bold text-blue-900">Fund Request Review</h2>
                                <p className="text-sm text-blue-800/80 mt-1">Review and take action on this funding request</p>
                            </div>
                            <button
                                onClick={closeModal}
                                className="p-2 rounded-xl border-2 border-blue-100 bg-white text-blue-900 font-bold hover:bg-blue-50"
                            >
                                ✕
                            </button>
                        </div>

                        <div className="space-y-4">
                            <div className="p-4 bg-blue-50/50 border-2 border-blue-100 rounded-2xl">
                                <div className="text-3xl font-bold text-blue-900 mb-2">
                                    ₹{active.amount?.toLocaleString() || 0}
                                </div>
                                <div className="space-y-2 text-sm">
                                    <div className="flex items-center gap-2">
                                        <span className="font-semibold text-blue-900">Status:</span>
                                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${active.status === "pending"
                                                ? "bg-amber-100 text-amber-800"
                                                : active.status === "approved"
                                                    ? "bg-green-100 text-green-800"
                                                    : "bg-red-100 text-red-800"
                                            }`}>
                                            {t(`status_${active.status}` as any)}
                                        </span>
                                    </div>
                                    {active.panchayatId && (
                                        <div><span className="font-semibold text-blue-900">Panchayat:</span> {active.panchayatId}</div>
                                    )}
                                    {active.issueId && (
                                        <div><span className="font-semibold text-blue-900">Issue ID:</span> {active.issueId}</div>
                                    )}
                                    {active.createdAt && (
                                        <div><span className="font-semibold text-blue-900">Submitted:</span> {fmtDate(active.createdAt)}</div>
                                    )}
                                </div>
                            </div>

                            {active.reason && (
                                <div className="p-4 bg-amber-50/50 border-2 border-amber-100 rounded-2xl">
                                    <div className="flex items-center gap-2 mb-2">
                                        <FiMessageSquare className="w-4 h-4 text-amber-700" />
                                        <span className="font-bold text-amber-900">Reason for Request</span>
                                    </div>
                                    <p className="text-sm text-amber-800">{active.reason}</p>
                                </div>
                            )}

                            <div>
                                <label className="block text-sm font-bold text-blue-900 mb-2">
                                    Your Comment (Optional)
                                </label>
                                <textarea
                                    value={comment}
                                    onChange={(e) => setComment(e.target.value)}
                                    rows={4}
                                    className="w-full rounded-2xl border-2 border-blue-200 bg-white px-4 py-3 text-blue-900 font-semibold outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-200 transition-all"
                                    placeholder="Add any comments or notes about your decision..."
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-3 mt-6">
                                <button
                                    disabled={acting}
                                    onClick={() => act("approved")}
                                    className="rounded-2xl bg-gradient-to-r from-green-600 to-emerald-700 text-white font-bold py-4 disabled:opacity-60 hover:from-green-700 hover:to-emerald-800 active:scale-95 transition-all duration-200"
                                >
                                    {acting ? "Processing..." : "✓ Approve Request"}
                                </button>

                                <button
                                    disabled={acting}
                                    onClick={() => act("rejected")}
                                    className="rounded-2xl bg-gradient-to-r from-red-600 to-rose-700 text-white font-bold py-4 disabled:opacity-60 hover:from-red-700 hover:to-rose-800 active:scale-95 transition-all duration-200"
                                >
                                    {acting ? "Processing..." : "✗ Reject Request"}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </Screen>
    );
}
