"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Screen from "../../../components/Screen";
import { auth, db } from "../../../lib/firebase";
import { doc, getDoc } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";

type Locale = "en" | "kn" | "hi";
type Role = "pdo" | "village_incharge" | "tdo" | "ddo";

export default function AuthorityStatusPage() {
  const router = useRouter();
  const params = useParams() as { locale?: string };
  const locale = (params?.locale || "en") as Locale;

  const t = useMemo(() => {
    const L: Record<Locale, any> = {
      en: {
        title: "Verification Status",
        subtitle: "Your authority account must be verified by Admin before you can access the dashboard.",
        loading: "Loading…",
        pendingTitle: "Pending Verification",
        pendingDesc: "Your request is submitted. Please wait — Admin will verify your details.",
        verifiedTitle: "Verified",
        verifiedDesc: "Your account is verified. You can now access your authority dashboard.",
        rejectedTitle: "Rejected",
        rejectedDesc: "Your verification was rejected. Please contact Admin or re-register with correct details.",
        reason: "Reason",
        actions: {
          goDashboard: "Go to Dashboard",
          logout: "Logout",
          registerAgain: "Register Again",
          backHome: "Back to Home",
        },
      },
      kn: {
        title: "ಪರಿಶೀಲನೆ ಸ್ಥಿತಿ",
        subtitle: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್ ಪ್ರವೇಶಿಸಲು ಮೊದಲು ಆಡ್ಮಿನ್ ನಿಮ್ಮ ಖಾತೆಯನ್ನು ಪರಿಶೀಲಿಸಬೇಕು.",
        loading: "ಲೋಡ್ ಆಗುತ್ತಿದೆ…",
        pendingTitle: "ಪರಿಶೀಲನೆ ಬಾಕಿ ಇದೆ",
        pendingDesc: "ನಿಮ್ಮ ವಿನಂತಿ ಸಲ್ಲಿಸಲಾಗಿದೆ. ದಯವಿಟ್ಟು ಕಾಯಿರಿ — ಆಡ್ಮಿನ್ ವಿವರಗಳನ್ನು ಪರಿಶೀಲಿಸುತ್ತಾರೆ.",
        verifiedTitle: "ಪರಿಶೀಲಿಸಲಾಗಿದೆ",
        verifiedDesc: "ನಿಮ್ಮ ಖಾತೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ. ಈಗ ನೀವು ಡ್ಯಾಶ್‌ಬೋರ್ಡ್ ಪ್ರವೇಶಿಸಬಹುದು.",
        rejectedTitle: "ನಿರಾಕರಿಸಲಾಗಿದೆ",
        rejectedDesc: "ನಿಮ್ಮ ಪರಿಶೀಲನೆ ನಿರಾಕರಿಸಲಾಗಿದೆ. ದಯವಿಟ್ಟು ಆಡ್ಮಿನ್ ಅನ್ನು ಸಂಪರ್ಕಿಸಿ ಅಥವಾ ಮರು ನೋಂದಣಿ ಮಾಡಿ.",
        reason: "ಕಾರಣ",
        actions: {
          goDashboard: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ಗೆ ಹೋಗಿ",
          logout: "ಲಾಗೌಟ್",
          registerAgain: "ಮರು ನೋಂದಣಿ",
          backHome: "ಮುಖಪುಟಕ್ಕೆ",
        },
      },
      hi: {
        title: "वेरिफिकेशन स्टेटस",
        subtitle: "डैशबोर्ड एक्सेस करने से पहले Admin द्वारा आपका अकाउंट verify होना जरूरी है।",
        loading: "लोड हो रहा है…",
        pendingTitle: "वेरिफिकेशन पेंडिंग",
        pendingDesc: "आपका रिक्वेस्ट सबमिट हो गया है। कृपया इंतज़ार करें — Admin verify करेंगे।",
        verifiedTitle: "Verified",
        verifiedDesc: "आपका अकाउंट verify हो गया है। अब आप डैशबोर्ड एक्सेस कर सकते हैं।",
        rejectedTitle: "Rejected",
        rejectedDesc: "आपका वेरिफिकेशन reject हो गया है। Admin से संपर्क करें या सही जानकारी से दोबारा रजिस्टर करें।",
        reason: "कारण",
        actions: {
          goDashboard: "डैशबोर्ड खोलें",
          logout: "लॉगआउट",
          registerAgain: "दोबारा रजिस्टर",
          backHome: "होम जाएँ",
        },
      },
    };
    return L[locale] || L.en;
  }, [locale]);

  const [authReady, setAuthReady] = useState(false);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<any>(null);

  const goRoleDashboard = (role: Role) => {
    if (role === "pdo") return router.replace(`/${locale}/authority/pdo/dashboard`);
    if (role === "village_incharge") return router.replace(`/${locale}/authority/vi/dashboard`);
    if (role === "tdo") return router.replace(`/${locale}/authority/tdo/dashboard`);
    return router.replace(`/${locale}/authority/ddo/dashboard`);
  };

  // ✅ Step 1: wait for Firebase Auth to resolve session (prevents login<->status loop)
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setAuthReady(true);
      if (!u) {
        router.replace(`/${locale}/authority/login`);
      }
    });
    return () => unsub();
  }, [router, locale]);

  // ✅ Step 2: after authReady + user exists, load authority profile
  useEffect(() => {
    if (!authReady) return;

    const u = auth.currentUser;
    if (!u) return; // already redirected to login above

    (async () => {
      setLoading(true);
      try {
        const snap = await getDoc(doc(db, "authorities", u.uid));
        if (!snap.exists()) {
          router.replace(`/${locale}/authority/register`);
          return;
        }

        const data = snap.data() as any;
        setProfile(data);

        const isVerified =
          data?.verified === true ||
          data?.status === "verified" ||
          data?.verification?.status === "verified";

        if (isVerified) {
          goRoleDashboard((data?.role || "pdo") as Role);
        }
      } finally {
        setLoading(false);
      }
    })().catch(() => setLoading(false));
  }, [authReady, locale]); // (router is stable enough; no need to include)

  const status: "pending" | "verified" | "rejected" = useMemo(() => {
    if (!profile) return "pending";
    if (profile?.verification?.status === "rejected") return "rejected";
    if (profile?.verified === true || profile?.verification?.status === "verified") return "verified";
    return "pending";
  }, [profile]);

  const reason = profile?.verification?.reason || profile?.rejectionReason || "";

  if (loading) {
    return (
      <Screen center>
        <p style={{ color: "#166534", fontWeight: 700 }}>{t.loading}</p>
      </Screen>
    );
  }

  return (
    <Screen padded>
      <div style={{ maxWidth: 520, margin: "0 auto" }}>
        <h1 style={{ fontSize: 28, fontWeight: 900, color: "#14532d" }}>{t.title}</h1>
        <p style={{ color: "#4d7c5e", fontWeight: 600, marginTop: 6 }}>{t.subtitle}</p>

        <div
          style={{
            marginTop: 18,
            background: "#fff",
            borderRadius: 18,
            border: "1px solid #bbf7d0",
            padding: 18,
            boxShadow: "0 1px 10px rgba(0,0,0,0.06)",
          }}
        >
          {status === "pending" && (
            <>
              <h2 style={{ color: "#854d0e", fontWeight: 900 }}>{t.pendingTitle}</h2>
              <p style={{ color: "#4d7c5e", fontWeight: 600 }}>{t.pendingDesc}</p>
            </>
          )}

          {status === "verified" && (
            <>
              <h2 style={{ color: "#166534", fontWeight: 900 }}>{t.verifiedTitle}</h2>
              <p style={{ color: "#4d7c5e", fontWeight: 600 }}>{t.verifiedDesc}</p>
              <button
                onClick={() => goRoleDashboard((profile?.role || "pdo") as Role)}
                style={{
                  marginTop: 12,
                  padding: "10px 14px",
                  borderRadius: 12,
                  background: "#16a34a",
                  color: "#fff",
                  fontWeight: 800,
                  border: "none",
                  cursor: "pointer",
                }}
              >
                {t.actions.goDashboard}
              </button>
            </>
          )}

          {status === "rejected" && (
            <>
              <h2 style={{ color: "#991b1b", fontWeight: 900 }}>{t.rejectedTitle}</h2>
              <p style={{ color: "#4d7c5e", fontWeight: 600 }}>{t.rejectedDesc}</p>
              {reason && (
                <div style={{ marginTop: 10, padding: 10, borderRadius: 12, background: "#fee2e2" }}>
                  <div style={{ fontSize: 12, fontWeight: 900, color: "#b91c1c" }}>{t.reason}</div>
                  <div style={{ fontWeight: 700, color: "#991b1b" }}>{reason}</div>
                </div>
              )}
              <button
                onClick={async () => {
                  await auth.signOut();
                  router.replace(`/${locale}/authority/register`);
                }}
                style={{
                  marginTop: 12,
                  padding: "10px 14px",
                  borderRadius: 12,
                  background: "#16a34a",
                  color: "#fff",
                  fontWeight: 800,
                  border: "none",
                  cursor: "pointer",
                }}
              >
                {t.actions.registerAgain}
              </button>
            </>
          )}

          <button
            onClick={async () => {
              await auth.signOut();
              router.replace(`/${locale}/role-select`);
            }}
            style={{
              marginTop: 12,
              padding: "10px 14px",
              borderRadius: 12,
              background: "#fff",
              color: "#166534",
              fontWeight: 800,
              border: "1px solid #bbf7d0",
              cursor: "pointer",
              marginLeft: 10,
            }}
          >
            {t.actions.logout}
          </button>
        </div>
      </div>
    </Screen>
  );
}
