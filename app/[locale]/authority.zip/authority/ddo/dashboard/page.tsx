"use client";

import { useEffect, useMemo } from "react";
import { useParams, useRouter } from "next/navigation";
import { auth, db } from "../../../../lib/firebase";
import { doc, getDoc } from "firebase/firestore";
import Screen from "../../../../components/Screen";

type Locale = "en" | "kn" | "hi";

export default function DDODashboardPage() {
    const router = useRouter();
    const params = useParams() as { locale?: string };
    const locale = (params?.locale || "en") as Locale;

    /* 🌐 Multilingual text */
    const t = useMemo(() => {
        const L: Record<Locale, any> = {
            en: {
                title: "DDO Dashboard",
                subtitle: "District-level monitoring & escalations",
                cards: {
                    escalations: "Escalated Issues",
                    unresolved: "Unresolved Cases",
                    analytics: "District Analytics",
                    reports: "Reports",
                },
                actions: {
                    open: "Open",
                    logout: "Logout",
                },
                loading: "Loading…",
            },
            kn: {
                title: "DDO ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
                subtitle: "ಜಿಲ್ಲಾ ಮಟ್ಟದ ಮೇಲ್ವಿಚಾರಣೆ ಮತ್ತು ಎಸ್ಕಲೇಶನ್",
                cards: {
                    escalations: "ಎಸ್ಕಲೇಟೆಡ್ ಸಮಸ್ಯೆಗಳು",
                    unresolved: "ಪರಿಹಾರವಾಗದ ಪ್ರಕರಣಗಳು",
                    analytics: "ಜಿಲ್ಲಾ ವಿಶ್ಲೇಷಣೆ",
                    reports: "ವರದಿಗಳು",
                },
                actions: {
                    open: "ತೆರೆ",
                    logout: "ಲಾಗೌಟ್",
                },
                loading: "ಲೋಡ್ ಆಗುತ್ತಿದೆ…",
            },
            hi: {
                title: "DDO डैशबोर्ड",
                subtitle: "जिला स्तर पर निगरानी और एस्केलेशन",
                cards: {
                    escalations: "एस्केलेटेड समस्याएँ",
                    unresolved: "अनसुलझे मामले",
                    analytics: "जिला एनालिटिक्स",
                    reports: "रिपोर्ट्स",
                },
                actions: {
                    open: "खोलें",
                    logout: "लॉगआउट",
                },
                loading: "लोड हो रहा है…",
            },
        };
        return L[locale] || L.en;
    }, [locale]);

    /* 🔐 Role protection */
    useEffect(() => {
        const guard = async () => {
            const u = auth.currentUser;
            if (!u) {
                router.replace(`/${locale}/authority/login`);
                return;
            }

            const snap = await getDoc(doc(db, "authorities", u.uid));
            if (!snap.exists()) {
                router.replace(`/${locale}/authority/status`);
                return;
            }

            const data = snap.data() as any;
            const isVerified =
                data?.verified === true ||
                data?.verification?.status === "verified";

            if (!isVerified || data?.role !== "ddo") {
                router.replace(`/${locale}/authority/status`);
            }
        };

        guard();
    }, [router, locale]);

    return (
        <Screen padded>
            <div className="max-w-5xl mx-auto">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
                    <div>
                        <h1 className="text-2xl sm:text-3xl font-extrabold text-green-900">
                            {t.title}
                        </h1>
                        <p className="text-sm text-green-900/70 mt-1">
                            {t.subtitle}
                        </p>
                    </div>

                    <button
                        onClick={async () => {
                            await auth.signOut();
                            router.replace(`/${locale}/role-select`);
                        }}
                        className="px-4 py-2 rounded-xl bg-red-50 border border-red-200 text-red-700 font-bold hover:bg-red-100 transition"
                    >
                        {t.actions.logout}
                    </button>
                </div>

                {/* Dashboard Cards */}
                <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <DDOCard
                        title={t.cards.escalations}
                        onClick={() => router.push(`/${locale}/authority/ddo/escalations`)}
                        cta={t.actions.open}
                    />
                    <DDOCard
                        title={t.cards.unresolved}
                        onClick={() => router.push(`/${locale}/authority/ddo/unresolved`)}
                        cta={t.actions.open}
                    />
                    <DDOCard
                        title={t.cards.analytics}
                        onClick={() => router.push(`/${locale}/authority/ddo/analytics`)}
                        cta={t.actions.open}
                    />
                    <DDOCard
                        title={t.cards.reports}
                        onClick={() => router.push(`/${locale}/authority/ddo/reports`)}
                        cta={t.actions.open}
                    />
                </div>
            </div>
        </Screen>
    );
}

/* 🧩 Reusable Card */
function DDOCard({
    title,
    cta,
    onClick,
}: {
    title: string;
    cta: string;
    onClick: () => void;
}) {
    return (
        <div className="bg-white border border-green-100 rounded-2xl p-5 shadow-sm flex flex-col justify-between">
            <h3 className="text-lg font-extrabold text-green-900">
                {title}
            </h3>

            <button
                onClick={onClick}
                className="mt-4 px-4 py-2 rounded-xl bg-green-700 text-white font-extrabold hover:brightness-95 active:scale-[0.99] transition"
            >
                {cta}
            </button>
        </div>
    );
}
