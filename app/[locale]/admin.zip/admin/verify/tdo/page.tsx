import VerifyRoleList from "../../../../components/admin/VerifyRoleList";

export default function Page() {
    return <VerifyRoleList role="tdo" routeTitleKey="tdo" />;
}