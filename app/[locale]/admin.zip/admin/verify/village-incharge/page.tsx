import VerifyRoleList from "../../../../components/admin/VerifyRoleList";

export default function Page() {
    return <VerifyRoleList role="village_incharge" routeTitleKey="vic" />;
}